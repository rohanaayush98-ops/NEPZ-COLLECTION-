# NEPZ COLLECTION Android App

This project wraps the supplied `nepz_collection.html` in an Android WebView.

Open this folder in Android Studio and Build > Build APK(s).
The generated debug APK will be under `app/build/outputs/apk/debug/`.
